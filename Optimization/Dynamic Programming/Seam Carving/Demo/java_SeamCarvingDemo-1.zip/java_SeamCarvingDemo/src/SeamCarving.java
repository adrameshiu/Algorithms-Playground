public class SeamCarving {
    static int[] carve_seam(int disruption[][]) {
        int[] seam = new int[disruption.length];

        // YOUR CODE HERE

        return seam;
    }
}
